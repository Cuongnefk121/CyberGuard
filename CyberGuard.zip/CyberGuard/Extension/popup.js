const BACKEND =
    "https://cyberguard-jx83.onrender.com/scan?domain=";

const input =
    document.getElementById("domain");

const button =
    document.getElementById("check");

const result =
    document.getElementById("result");

const minimize =
    document.getElementById("minimize");

const close =
    document.getElementById("close");


/* =========================
   THU NHỎ / MỞ RỘNG
========================= */

minimize.addEventListener(
    "click",
    function()
    {
        document.body.classList.toggle(
            "minimized"
        );
    }
);


/* =========================
   ĐÓNG POPUP
========================= */

close.addEventListener(
    "click",
    function()
    {
        window.close();
    }
);


/* =========================
   LẤY DOMAIN
========================= */

function getDomain(value)
{
    value =
        value.trim();

    if (!value)
    {
        return "";
    }

    try
    {
        if (
            !value.startsWith("http://") &&
            !value.startsWith("https://")
        )
        {
            value =
                "https://" +
                value;
        }

        let domain =
            new URL(value).hostname;

        domain =
            domain.replace(
                /^www\./,
                ""
            );

        return domain;
    }
    catch (e)
    {
        return "";
    }
}


/* =========================
   KIỂM TRA WEBSITE
========================= */

async function checkWebsite()
{
    let domain =
        getDomain(
            input.value
        );

    if (!domain)
    {
        result.innerText =
            "❌ Tên miền không hợp lệ.";

        return;
    }

    button.disabled =
        true;

    result.innerText =
        "🔄 Đang kiểm tra " +
        domain +
        "...";

    try
    {
        let response =
            await fetch(
                BACKEND +
                encodeURIComponent(
                    domain
                )
            );

        if (!response.ok)
        {
            throw new Error(
                "HTTP " +
                response.status
            );
        }

        let data =
            await response.json();

        let malicious =
            Number(
                data.malicious
            );

        if (
            Number.isNaN(
                malicious
            )
        )
        {
            throw new Error(
                "Kết quả không hợp lệ."
            );
        }


        if (malicious >= 3)
        {
            result.innerText =
                "⚠️ CẢNH BÁO: " +
                malicious +
                " engine phát hiện nguy hiểm.";
        }
        else
        {
            result.innerText =
                "✅ Chưa phát hiện nguy hiểm. " +
                malicious +
                " engine.";
        }
    }
    catch (error)
    {
        console.error(
            "URLChecker ERROR:",
            error
        );

        result.innerText =
            "❌ Không thể kết nối Backend.";
    }

    button.disabled =
        false;
}


/* =========================
   NÚT KIỂM TRA
========================= */

button.addEventListener(
    "click",
    checkWebsite
);


/* =========================
   ENTER ĐỂ KIỂM TRA
========================= */

input.addEventListener(
    "keydown",
    function(event)
    {
        if (
            event.key === "Enter"
        )
        {
            checkWebsite();
        }
    }
);